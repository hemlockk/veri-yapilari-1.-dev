/**
* @file G191210012
* @description sayilar.txt dosyasını okuyup her bir satir için birbirine bağlı birer liste oluşturuyor ve bunlardan en uzun olanla en kısa olan satırı çaprazlama işlemine tabi tutup ekrana yazdırıyor
* @course 2. öğretim B grubu
* @assignment 1. ödev
* @date Kodu 26.11.2020
* @author Ali Yusuf Akbay ali.yusuf01@hotmail.com
*/
#include <iostream>
#include <fstream>
#include <string>
#include "CDLL.hpp"
using namespace std;
int* sayilardosyasi() {
    
    ifstream MyFile("./doc/Sayilar.txt");
    int satirsayisi = 0;
    int* satirdakielemansayisi = new int[400];
    for (int i = 0; i < 400; i++) {
        satirdakielemansayisi[i] = 0;
    }
    string myText;
    while (getline(MyFile, myText)) {
        myText = myText + ' ';
        int tracer = 0;
        int traker = 0;
        while (tracer < myText.length()) {
            if (myText.at(tracer) == '0' || myText.at(tracer) == '1' || myText.at(tracer) == '2' || myText.at(tracer) == '3' || myText.at(tracer) == '4' || myText.at(tracer) == '5' || myText.at(tracer) == '6' || myText.at(tracer) == '7' || myText.at(tracer) == '8' || myText.at(tracer) == '9') {
                tracer++;
            }
            else {
                if (tracer != traker) {
                    satirdakielemansayisi[satirsayisi]++;
                    tracer--;
                }
                tracer++;
                traker = tracer;
            }
        }
        satirsayisi++;
    }
	MyFile.close();
    return &satirdakielemansayisi[0];

};
int satirsayisinibulma() {
    ifstream MyFile("./doc/Sayilar.txt");
    string myText;
    int satirsayisi = 0;
    while (getline(MyFile, myText)) {    
            satirsayisi++;
    }
	MyFile.close();
    return satirsayisi + 1;
};
int enuzunsatiribulma(int* p, int satir) {
    int enuzunsatir = 0;
    int enUzunsatirelemansayisi = 0;
    for (int i = 0; i < satir; i++) {
        if (*(p + i) > enUzunsatirelemansayisi && *(p + i) != 0) {
            enUzunsatirelemansayisi = *(p + i);
            enuzunsatir = i + 1;
        }
    }
    return enuzunsatir;
}
int enkisasatiribulma(int* p, int satir) {
    int enkisasatir = 0;
    int EnKisaSatirElemanSayisi = 400;
    for (int i = 0; i < satir; i++) {
        if (*(p + i) < EnKisaSatirElemanSayisi && *(p + i) != 0) {
            EnKisaSatirElemanSayisi = *(p + i);
            enkisasatir = i + 1;
        }
    }
    return enkisasatir;
};
CDLL* satiriEkle(int satirNum) {
    CDLL* LinkedList = new CDLL();
    ifstream MyFile("./doc/Sayilar.txt");
    string myText;
    int satirsayisi = 0;
    while (getline(MyFile, myText)) {
        myText = myText + ' ';
        satirsayisi++;
        if (satirsayisi == satirNum) {
            int numbers[400];
            int tracer = 0;
            int traker = 0;
            int i = 0;
            while (tracer != myText.length()) {
                if (myText.at(tracer) == '0' || myText.at(tracer) == '1' || myText.at(tracer) == '2' || myText.at(tracer) == '3' || myText.at(tracer) == '4' || myText.at(tracer) == '5' || myText.at(tracer) == '6' || myText.at(tracer) == '7' || myText.at(tracer) == '8' || myText.at(tracer) == '9') {
                    tracer++;
                }
                else {
                    if (tracer != traker) {
                        numbers[i] = stoi(myText.substr(traker, tracer - traker));
                        LinkedList->Insert_last(numbers[i]);
                        i++;
                        tracer--;
                    }
                    tracer++;
                    traker = tracer;
                }
            }
        }
    }
	MyFile.close();
    return LinkedList;
};
int main()
{
    const int satirsayisi = satirsayisinibulma();
    cout << endl << "----------------------------------" << endl;
    CDLL** listelerinlistesi = new CDLL * [satirsayisi];
    for (int i = 0; i < satirsayisi; i++) {
        listelerinlistesi[i] = satiriEkle(i);
        listelerinlistesi[i]->reader();
        cout << endl;
    }
    cout << endl << "----------------------------------" << endl;
    int* p = sayilardosyasi();
    int enuzunsatir = enuzunsatiribulma(p, satirsayisi);
    int enkisasatir = enkisasatiribulma(p, satirsayisi);
    cout <<"en kisa satir = " << enkisasatir << endl;
    CDLL* kisa = listelerinlistesi[enkisasatir];
    cout << "orta dugum adresi: " << kisa->adressBilgisi() << endl;
    cout << "degerleri: ";
    kisa->reader();
    cout << endl << "----------------------------------" << endl;
    cout <<"en uzun satir = " << enuzunsatir << endl;
    CDLL* uzun = listelerinlistesi[enuzunsatir];
    cout << "orta dugum adresi: " << uzun->adressBilgisi() << endl;
    cout << "degerleri: ";
    uzun->reader();
    cout << endl << "----------------------------------" << endl;
    int uzunsag[200];
    int uzunsol[200];
    int kisasag[200];
    int kisasol[200];
    Node* kisaItr = kisa->return_head()->next->next;
    Node* uzunItr = uzun->return_head()->next->next;
    int j = 0;
    for (int i = 0; i < (uzun->count() / 2); i++) {
        uzunsag[i] = uzunItr->data;
        uzunItr = uzunItr->next;
        if (i < kisa->count() / 2) {
            kisasag[j] = kisaItr->data;
            kisaItr = kisaItr->next;
            j++;
        }
    }
    cout << endl;
    j = 0;
    kisaItr = kisa->return_head()->next->prev;
    uzunItr = uzun->return_head()->next->prev;
    for (int i = 0; i < (uzun->count() / 2); i++) {
        uzunsol[i] = uzunItr->data;
        uzunItr = uzunItr->prev;
        if (i < kisa->count() / 2) {
            kisasol[j] = kisaItr->data;
            kisaItr = kisaItr->prev;
            j++;
        }
    }
    int uzunTaraf = uzun->count() / 2;
    int kisaTaraf = kisa->count() / 2;
    for (int i = 0; i < uzunTaraf; i++) {
        uzun->remove_Last();
    }
    for (int i = 0; i < uzunTaraf; i++) {
        uzun->remove_First();
    }
    for (int i = 0; i < kisaTaraf; i++) {
        uzun->Insert_First(kisasag[i]);
    }
    for (int i = 0; i < kisaTaraf; i++) {
        uzun->Insert_last(kisasol[i]);
    }

    /////////////////////////////////////////////

    for (int i = 0; i < kisaTaraf; i++) {
        kisa->remove_Last();
    }
    for (int i = 0; i < kisaTaraf; i++) {
        kisa->remove_First();
    }
    for (int i = 0; i < uzunTaraf; i++) {
        kisa->Insert_First(uzunsag[i]);
    }
    for (int i = 0; i < uzunTaraf; i++) {
        kisa->Insert_last(uzunsol[i]);
    }
    cout << "caprazlama yapildiktan sonra kisa olan satir : ";
    kisa->reader();
    cout << endl << "----------------------------------" << endl;
    cout << "caprazlama yapildiktan sonra uzun olan satir : ";
    uzun->reader();
    cout << endl;
	delete[] listelerinlistesi;
    system("pause");
    return 0;
}