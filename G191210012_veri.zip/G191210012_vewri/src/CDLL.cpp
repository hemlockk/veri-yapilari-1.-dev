/**
* @file G191210012
* @description sayilar.txt dosyasını okuyup her bir satir için birbirine bağlı birer liste oluşturuyor ve bunlardan en uzun olanla en kısa olan satırı çaprazlama işlemine tabi tutup ekrana yazdırıyor
* @course 2. öğretim B grubu
* @assignment 1. ödev
* @date Kodu 26.11.2020
* @author Ali Yusuf Akbay ali.yusuf01@hotmail.com
*/
#include "CDLL.hpp"
using namespace std;
    CDLL::CDLL() {
        size = 0;
        head = new Node();
        head_index = 0;
    }
    bool CDLL::isEmpty() {
        return head->next == NULL;
    }
    int CDLL::count() {
        return size;
    }
    Node* CDLL::return_head() {
        return head;
    }
    void CDLL::header_stepNext() {
        head->next = head->next->next;
        head_index++;
    }
    void CDLL::header_stepBack() {
        head->next = head->next->prev;
        head_index--;
    }
    Node* CDLL::adressBilgisi() {
        return head;
    }
    void CDLL::Insert_last(int obj) {
        Node* itr;
        Node* itr2;
        if (size == 0) {
            Node* newNode = new Node();
            head->next = newNode;
            newNode->data = obj;
            newNode->next = newNode;
            newNode->prev = newNode;
        }
        else {
            Node* newNode = new Node();
            newNode->data = obj;
            itr = head->next;
            for (int i = 0; i < size/2; i++) {
                itr = itr->next;
            }
            itr2 = itr->next;
            itr->next = newNode;
            itr->next->prev = itr;
            itr->next->next =  itr2;
            itr->next->next->prev = itr->next;
        }
        if (size % 2 == 0 && size != 0) {
            header_stepNext();
        }
        size++;
    }
    void CDLL::Insert_First(int obj) {
        int itrMoves = 0;
        Node* itr;
        Node* itr2;
        if (size == 0) {
            Node* newNode = new Node();
            head->next = newNode;
            newNode->data = obj;
            newNode->next = newNode;
            newNode->prev = newNode;
        }
        else {
            if (size % 2 == 1 && size != 0) {
                itrMoves = (size / 2);
            }
            if ((size % 2 == 0 && size != 0)) {
                itrMoves = (size / 2) - 1;
            }
            Node* newNode = new Node();
            newNode->data = obj;
            itr = head->next;
            for (int i = 0; i < itrMoves; i++) {
                itr = itr->prev;
            }
            itr2 = itr->prev;
            itr->prev = newNode;
            itr->prev->next = itr;
            itr->prev->prev = itr2;
            itr->prev->prev->next = itr->next;
        }
        if (size % 2 == 0 && size != 0) {
            head_index++;
        }
        if (size % 2 == 1 && size != 0) {
            head->next = head->next->prev;
        }
        size++;
    }
    void CDLL::remove_Last() {
        if (size == 0) {
            return;
        } 
        else if(size == 1){
            delete head->next;
            size = 0;
        }
        else {
            Node* itr = head->next;
            Node* itr2;
            for (int i = 0; i < (size / 2) - 1; i++) {
                itr = itr->next;
            }
            itr2 = itr->next;
            itr->next = itr->next->next;
            itr->next->prev = itr;
            delete itr2;
            size--;
            if (size % 2 == 0 && size != 0) {
                header_stepBack();
            }
        }

    }
    void CDLL::remove_First() {
        if (size == 0) {
            return;
        }
        else if (size == 1) {
            free(head->next);
            size = 0;
        }
        else if (size == 2) {
            Node* p = head->next;
            head->next = head->next->next;
            free(p);
            size--;

        }
        else {
            int itrMoves = 0;
            Node* itr = head->next;
            Node* itr2;
            if (size % 2 == 1 && size != 0) {
                itrMoves = (size / 2);
            }
            else if((size % 2 == 0 && size != 0)){
                itrMoves = (size / 2) - 1;
            }
            for (int i = 0; i < itrMoves - 1; i++) {
                itr = itr->prev;
            }
            itr2 = itr->prev;
            itr->prev = itr->prev->prev;
            itr->prev->next = itr;
            free(itr2);
            size--;
            if (size % 2 == 1 && size != 0) {
                header_stepNext();
                head_index--;
            }
            if (size % 2 == 0 && size != 0) {
                head_index--;
            }

        }
    }
    void CDLL::reader(){
   
            Node* itr = head->next;
            for (int i = 0; i < head_index; i++) {
                itr = itr->prev;
            }
            for (int i = 0; i < size; i++) {
                cout << itr->data << ' ';
                itr = itr->next;
            }
        
    }